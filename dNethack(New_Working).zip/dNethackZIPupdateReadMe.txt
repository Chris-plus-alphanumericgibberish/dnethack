this contains the actual working prebuilt windows binary of the current source code as of
October 5th 2017
with ALL the fixes, new roles, and also new races.